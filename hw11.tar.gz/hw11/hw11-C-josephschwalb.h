#ifndef HW11_C_JOSEPHSCHWALB_H
#define HW11_C_JOSEPHSCHWALB_H

/*
Joseph Schwalb
CSCI 230
MWF 0900-0950
*/

void free_list(struct node* head);

#endif
