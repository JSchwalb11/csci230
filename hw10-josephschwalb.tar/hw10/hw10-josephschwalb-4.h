#ifndef HW10_JOSEPHSCHWALB_4_H
#define HW10_JOSEPHSCHWALB_4_H

/*
Joseph Schwalb
CSCI 230
MWF 0900-0950
*/

void main(int argc, char *argv[]);

#endif
