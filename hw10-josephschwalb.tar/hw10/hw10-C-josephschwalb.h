#ifndef HW10_C_JOSEPHSCHWALB_H
#define HW10_C_JOSEPHSCHWALB_H

/*
Joseph Schwalb
CSCI 230
MWF 0900-0950
*/

void free_list(struct node* head);

#endif
